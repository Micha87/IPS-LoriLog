# Michael Westphal

Folgende Module beinhaltet das Michael Westphal Repository:

- __ELT Lite__ ([Dokumentation](ELT%20Lite))  
	Kurze Beschreibung des Moduls.